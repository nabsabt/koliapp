function greyPattern(){
    document.body.style.backgroundColor = "#e6e6e6";
    document.getElementById("main_container").style.borderColor="#333333";
}

function defaultPattern(){
    document.body.style.backgroundColor = "rgb(246,181,23)";
    document.getElementById("main_container").style.borderColor="rgb(21,103,147)";
}